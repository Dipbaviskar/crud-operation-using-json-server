export class employeeModel{
    id:number = 1;
    firstname:string = '';
    lastname:string = '';
    email:string = '';
    contactno:string = '';
    salary:string = '';

}